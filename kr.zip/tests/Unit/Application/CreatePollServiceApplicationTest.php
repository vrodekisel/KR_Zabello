<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

/**
 * Заглушка для будущих unit-тестов прикладного слоя.
 * Сейчас просто предотвращает warning от PHPUnit.
 */
final class CreatePollServiceApplicationTest extends TestCase
{
    public function testPlaceholder(): void
    {
        $this->assertTrue(true);
    }
}
